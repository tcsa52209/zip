﻿using System;

namespace GenericCRUDServices
{
    public  class BaseService
    {
    }
}
