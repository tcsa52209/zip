using System;
using System.Net;
using System.Net.Mail;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using Newtonsoft.Json;
using Models;
using System.IO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Utils
{
    public static partial class Utils
    {
        public static string MessageClass { set; get; }
        public static string Message { set; get; }
        public static string JSONResult { set; get; }
        public static HttpResponseMessage Response { set; get; }
        public static Exception Ex { set; get; }

        private static int result = 0;
        public static int Result
        {
            set
            {
                result = value;
                if (result == 0 )
                {
                    MessageClass = "row bg-sucess";
                    Message = Response?.StatusCode.ToString();
                }
                else
                {
                    MessageClass = "row bg-danger";
                    Message = $"Http Response: {Response?.StatusCode}";
                    if (Ex != null)
                        Message += Ex.ToString();
                }
            }
            get
            {
                return result;
            }
        }

        private static void Init()
        {
            Message = "";
            Response = null;
            JSONResult = "";
            Ex = null;
        }

        public static string Extract( this string text, string start, string end = "")
        {
            string result = "";
            if (string.IsNullOrEmpty(end))
                end = "\r\n";
            int index = text.ToLower().IndexOf(start.ToLower());
            if ( index >=0 )
            {
                index += start.Length;
                int index2 = text.IndexOf(end.ToLower(), index);
                if (index2 > index)
                    result = text.Substring(index, index2 - index).Trim();
            }
            return result;
        }
        public static string DateString(this DateTime dt)
        {
            return $"{dt.Year.ToString().PadLeft(4, '0')}-{dt.Month.ToString().PadLeft(2, '0')}-{dt.Day.ToString().PadLeft(2, '0')}_{dt.Hour.ToString().PadLeft(2, '0')}-{dt.Minute.ToString().PadLeft(2, '0')}-{dt.Second.ToString().PadLeft(2, '0')}-{dt.Millisecond.ToString().PadLeft(3, '0')}";
        }

        public static string GetMailTo(string fileName)
        {
            string mailto = "";
            if (File.Exists(fileName))
                mailto = File.ReadAllText(fileName);
            return mailto;
        }


        //send gmail
        //https://garrymarsland.com/sending-email-from-a-net-core-2-1/
        //YOU MUST PUT YOUR GMAIL ACCOUNT IN UNSECURE MODE TO ALLOW THROW MAILS

        public static void SendGMail(string from, string to, string subject, string body)
        {
            from = "tcsa52209@gmail.com";
            try
            {
                using (var message = new MailMessage())
                {
                    message.To.Add(new MailAddress(to, "TCS RoboEngine"));
                    message.From = new MailAddress(from, "TCS RoboEngine");
                    //message.CC.Add(new MailAddress("cc@email.com", "CC Name"));
                    //message.Bcc.Add(new MailAddress("bcc@email.com", "BCC Name"));
                    message.Subject = subject;
                    message.Body = body;
                    message.IsBodyHtml = true;

                    using (var client = new SmtpClient("smtp.gmail.com"))
                    {
                        client.Port = 587;
                        client.UseDefaultCredentials = false;
                        client.EnableSsl = true;
                        client.UseDefaultCredentials = true;
                        client.Credentials = new NetworkCredential(from, "Esteeselpwd01");
                        client.Send(message);
                    }
                }
            }
            catch(Exception ex)
            {
                string s = "";
            }
        }

        public static void SendMail(string from, string to, string subject, string body)
        {
            SendGMail(from, to, subject, body);
            /*
            EmailMessage m = new EmailMessage()
            {
                emailFrom = from,
                emailTo = to,
                emailSubject = subject,
                bodyHtml = body
            };

            string sm = System.Text.Json.JsonSerializer.Serialize<EmailMessage>(m);
            Post("http://matlkipceapp005:9014/prod/send-email/", sm);
            */
        }

        //async
        public async static  void CallUrl(string url, string userName, string passwd, string json)
        {
            //var userName = "RoboEngine";
            //var passwd = "Pwcwelcome2";
            //var url = "https://uipath-unattended-dev.pwc.com/odata/Jobs/UiPath.Server.Configuration.OData.StartJobs";
            //url = "https://uipath-unattended-dev.pwc.com/api/account/authenticate";

            using var client = new HttpClient();

            var authToken = Encoding.ASCII.GetBytes($"{userName}:{passwd}");
            client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic",
                    Convert.ToBase64String(authToken));
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            //await
            var result =  await client.PostAsync(url,content);

            var content2 = await result.Content.ReadAsStringAsync();
            Console.WriteLine(content);
        }

        public static void PostUIPath(string url, string json)
        {
            var httpClientHandler = new HttpClientHandler()
            {
                Credentials = new NetworkCredential("RoboEngine", "Pwcwelcome2", "uipath-unattended-dev.pwc.com"),
            };

            var httpClient = new HttpClient(httpClientHandler);
            httpClient.DefaultRequestHeaders.Accept.Clear();
            httpClient.DefaultRequestHeaders.Accept.Add(
                new MediaTypeWithQualityHeaderValue("application/json"));
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            //var result = await httpClient.GetString(url,json);
            var result = httpClient.PostAsync(url, content).Result;

            //return result;   

        }

        public static HttpResponseMessage Get(string url, string token = "")
        {
            var client = new HttpClient();

            if (!string.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer", token);
            }

            try
            {
                var result = client.GetAsync(url).Result;

                return result;   //.ToString();
            }
            catch (Exception ex)
            {
                string s = $"Error calling WEB Method:{ex.Message}";
                return null;

            }
        }


        //http request basic authentication
        //http://zetcode.com/csharp/httpclient/
        public static HttpResponseMessage Post(string url, string jsonString, string token = "" )
        {
            var client = new HttpClient();

            if (!string.IsNullOrEmpty(token))
            {
                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue("Bearer",token);
            }

            var content = new StringContent(jsonString, Encoding.UTF8, "application/json");
            try
            {
                var result = client.PostAsync(url, content).Result;
                
                return result;   //.ToString();
            }
            catch (Exception ex)
            {
                string s = $"Error calling WEB Method:{ex.Message}";
                return null;

            }
        }

        public static int SendMail(this string from, string password, string to, string subject, string text)
        {
            try
            {
                using (var mailMessage = new MailMessage())
                {
                    using (var client = new SmtpClient("smtp.gmail.com", 587))
                    {
                        //provide credentials
                        client.Credentials = new NetworkCredential(from, password);
                        client.EnableSsl = true;

                        // configure the mail message
                        mailMessage.From = new MailAddress("abcdefgh@gmail.com");
                        mailMessage.To.Insert(0, new MailAddress("abcdefgh@gmail.com"));
                        mailMessage.Subject = "Learn SMTP sending mail in .NET Core";
                        //mailMessage.Body = text;//"You did it ";
                        //  oMail.HtmlBody = "<font size=5>This is</font> <font color=red><b>a test</b></font>";


                        //send email
                        client.Send(mailMessage);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return 0;
        }


        public static string GetJSON(this string url)
        {
            Init();
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(url);
            

            Response = client.GetAsync(url).Result;
            if (Response.IsSuccessStatusCode)
                JSONResult = Response.Content.ReadAsStringAsync().Result;
            else
            {
                Result = -1;
                JSONResult = Result.ToString();
            }

            return JSONResult;

        }

        public static string PostJSON(this string url, string jsonString )
        {
            Init();
            var client = new HttpClient();
            var content = new StringContent(jsonString, Encoding.UTF8, "application/json");
            try
            {
                Response = client.PostAsync(url, content).Result;
                if (Response.StatusCode == HttpStatusCode.OK)
                {
                    JSONResult = Response.Content.ReadAsStringAsync().Result;
                }
                else
                    Result = -2;
            }
            catch(Exception ex)
            {
                Ex = ex;
                Result = -3;
            }
            return JSONResult;
        }


        public static string JSONSerialize<T>(this T obj)
        {
            Init();
            try
            {
                JSONResult = System.Text.Json.JsonSerializer.Serialize<T>(obj);
            }
            catch(Exception ex)
            {
                Ex = ex;
                Result = -1;
            }
            return JSONResult;
        }

        public static int JSONDeserialize<T>(this string jsonString, ref T obj )
        {
            Init();
            try
            {
                obj = System.Text.Json.JsonSerializer.Deserialize<T>(jsonString);
            }
            catch(Exception ex)
            {
                Ex = ex;
                Result = -2;
            }
            return Result;
        }

        public static int JSONDeserializeNewtonSoft<T>(this string jsonString, ref T obj)
        {
            Init();
            try
            {
                obj = JsonConvert.DeserializeObject<T>(jsonString);
            }
            catch (Exception ex)
            {
                Ex = ex;
                Result = -2;
            }
            return Result;
        }


        public static string CleanPath(this string path)
        {
            path = path.Trim();
            if (!path.EndsWith(Path.DirectorySeparatorChar))
                path += Path.DirectorySeparatorChar;
            return path;
        }


        public static int JSONDeserializeList<T>(ref List<T> obj, string jsonString, bool checkEmptyList = false )
        {
            Init();
            try
            {
                obj = System.Text.Json.JsonSerializer.Deserialize<List<T>>(jsonString);
                if ( checkEmptyList && obj != null && obj.Count == 0)
                {
                    //deserialize with newtonsoft
                    obj = JsonConvert.DeserializeObject<List<T>>(jsonString);
                }
            }
            catch (Exception ex)
            {
                Ex = ex;
                Result = -2;
            }
            return Result;
        }

        public static string Capitalize(this string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                string cap = value.Substring(0,1).ToUpper();
                if (value.Length > 1)
                    cap += value.Substring(1).ToLower();
                return cap;
            }
            return value;
        }

    }
}
