using System;
using System.Collections.Generic;
using System.Text;

namespace Models
{
    public class EmailMessage
    {
        public string emailFrom { set; get; }
        public string emailTo { set; get; }
        public string emailSubject { set; get; }
        public string bodyPlain { set; get; }
        public string bodyHtml { set; get; }
    }
}
