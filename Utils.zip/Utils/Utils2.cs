﻿using System;
using System.Collections.Generic;
using System.Text;
using Models;
using System.IO;
using Utils;

namespace Utils
{
    public static partial class Utils
    {


        public static string GetYMDw(this DateTime dt)
        {
            return $"{dt.Year.ToString()}/{dt.Month.ToString().PadLeft(2, '0')}/{dt.Day.ToString().PadLeft(2, '0')} {dt.DayOfWeek.ToString().Substring(0, 3).ToUpper()}";
        }

        public static string GetHM(this DateTime dt)
        {
            return $"{dt.Hour.ToString().PadLeft(2, '0')}:{dt.Minute.ToString().PadLeft(2, '0')}";
        }

        public static string GetYYYYMM(this DateTime dt)
        {
            return dt.Year.ToString() + dt.Month.ToString().PadLeft(2, '0');
        }

        public static string DateStringCompact(this DateTime dt)
        {
            return $"{dt.Year.ToString().PadLeft(4, '0')}{dt.Month.ToString().PadLeft(2, '0')}{dt.Day.ToString().PadLeft(2, '0')}.{dt.Hour.ToString().PadLeft(2, '0')}{dt.Minute.ToString().PadLeft(2, '0')}{dt.Second.ToString().PadLeft(2, '0')}{dt.Millisecond.ToString().PadLeft(3, '0')}.{dt.DayOfWeek.ToString().Substring(0, 3).ToUpper()}";
        }




        //send gmail
        //https://garrymarsland.com/sending-email-from-a-net-core-2-1/
        //YOU MUST PUT YOUR GMAIL ACCOUNT IN UNSECURE MODE TO ALLOW THROW MAILS


        //async






        public static T JSONDeserialize<T>(this string jsonString)
        {
            Init();
            try
            {
                var obj = System.Text.Json.JsonSerializer.Deserialize<T>(jsonString);
                return obj;
            }
            catch (Exception ex)
            {
                Ex = ex;
                Result = -2;
            }
            return default;
        }


        public static bool IsImage(this string s)
        {
            s = s.ToLower();
            return s.Contains(".jpg") || s.Contains(".jpeg") ||
                s.Contains(".png") || s.Contains(".bmp") ||
                s.Contains(".webm");
        }
        public static bool IsAudio(this string s)
        {
            s = s.ToLower();
            return s.Contains(".mp3") || s.Contains(".wav") ||
                s.Contains(".acc") || s.Contains(".3gp") ||
                s.Contains(".amr") || s.Contains(".ogg") || s.Contains(".amr")
                || s.Contains(".wma");
        }

        public static bool IsVideo(this string s)
        {
            s = s.ToLower();
            return s.Contains(".mp4") || s.Contains(".mpg") ||
                s.Contains(".mpeg") || s.Contains(".vob") || s.Contains(".avi")
                || s.Contains(".mov") || s.Contains(".wmv");
        }

        public static string convertImageToDisplay(this MemoryStream ms)
        {
            if (ms != null)
            {
                var imageArray = ms.ToArray();
                var base64 = Convert.ToBase64String(imageArray);
                return string.Format("data:/image/jpg;base64,{0}", base64);
            }
            return "";
        }

    }
}
